<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=icomp',
    'username' => 'giselle',
    'password' => '123456',
    'charset' => 'utf8',
];
