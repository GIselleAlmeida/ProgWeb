<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
  //FUNÇÃO DATE() 
  echo $data = date("d/m/Y"); 
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
    	Trabalho Final da disciplina Programação Web<br/>
    	Aluna: Giselle de Almeida Costa<br/>
    	Matricula: 21354857<br/>
    	Professor: David Fernandes<br/>
    </p>


    <code><?= __FILE__ ?></code>
</div>
