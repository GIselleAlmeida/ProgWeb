<?php
/* @var $this yii\web\View */
use yii\helpers\Html;
$this->title = 'Icomp';
?>
<div class="site-index">

    <div class="jumbotron">
       <span class="super"> <?=Html::img('@web/icomp.png',array('width'=>'150','height'=>'85'))?> </span>

        <b><h1 onmouseover="handleMouseOver(this)"onmouseout="handleMouseOut(this)">Instituto de Computação</h1></b>

       <br/> <br/><br/> <p ><a class="btn btn-lg btn-success" href="http://icomp.ufam.edu.br/">Clique para acessar o site do icomp</a></p>
    </div>

<script type="text/javascript">
function handleMouseOver(elem) {

 elem.style.color='pink';

}
function handleMouseOut(elem) {
 elem.style.removeProperty('color');
 elem.style.removeProperty('background');
}
</script>

<style type="text/css">
    span{position:relative;font-size: 2em}
    .super{position:relative; top:70px;left: -430px}
    .sub{position: relative;bottom: 20px;}
</style>


   